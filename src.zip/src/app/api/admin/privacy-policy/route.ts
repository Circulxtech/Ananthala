import { type NextRequest, NextResponse } from "next/server"
import connectDB from "@/lib/mongodb"
import PrivacyPolicy from "@/models/PrivacyPolicy"

// GET privacy policy
export async function GET() {
  try {
    await connectDB()

    let privacyPolicy = await PrivacyPolicy.findOne()

    // If no privacy policy exists, create default one
    if (!privacyPolicy) {
      privacyPolicy = await PrivacyPolicy.create({
        title: "Privacy Policy",
        content: "",
        sections: [],
        lastUpdated: new Date(),
      })
    }

    return NextResponse.json({
      success: true,
      privacyPolicy,
    })
  } catch (error: any) {
    console.error("Error fetching privacy policy:", error)
    return NextResponse.json(
      { success: false, message: "Failed to fetch privacy policy", error: error.message },
      { status: 500 },
    )
  }
}

// UPDATE privacy policy
export async function PUT(request: NextRequest) {
  try {
    await connectDB()

    const body = await request.json()
    const { title, content, sections } = body

    if (!title || !content) {
      return NextResponse.json(
        { success: false, message: "Title and content are required" },
        { status: 400 },
      )
    }

    let privacyPolicy = await PrivacyPolicy.findOne()

    if (!privacyPolicy) {
      privacyPolicy = await PrivacyPolicy.create({
        title,
        content,
        sections: sections || [],
        lastUpdated: new Date(),
      })
    } else {
      privacyPolicy.title = title
      privacyPolicy.content = content
      privacyPolicy.sections = sections || []
      privacyPolicy.lastUpdated = new Date()
      await privacyPolicy.save()
    }

    return NextResponse.json({
      success: true,
      message: "Privacy policy updated successfully",
      privacyPolicy,
    })
  } catch (error: any) {
    console.error("Error updating privacy policy:", error)
    return NextResponse.json(
      { success: false, message: "Failed to update privacy policy", error: error.message },
      { status: 500 },
    )
  }
}
