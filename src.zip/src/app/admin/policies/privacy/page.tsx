"use client"

import { PrivacyPolicyForm } from "@/components/admin/privacy-policy-form"
import { Card } from "@/components/ui/card"

export default function PrivacyPolicyManagementPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-semibold text-[#6D4530] mb-2">Privacy Policy Management</h1>
        <p className="text-[#8B5A3C]/70">
          Edit your website&apos;s privacy policy. Changes will be reflected on your public privacy policy page.
        </p>
      </div>

      <Card className="p-6 border-[#E5D5C5] bg-white">
        <PrivacyPolicyForm />
      </Card>
    </div>
  )
}
