"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Spinner } from "@/components/ui/spinner"
import { toast } from "sonner"
import { X, Plus } from "lucide-react"

interface Section {
  heading: string
  description: string
}

interface PrivacyPolicy {
  _id?: string
  title: string
  content: string
  sections: Section[]
  lastUpdated?: Date
}

export function PrivacyPolicyForm() {
  const [formData, setFormData] = useState<PrivacyPolicy>({
    title: "Privacy Policy",
    content: "",
    sections: [],
  })

  const [isLoading, setIsLoading] = useState(false)
  const [isFetching, setIsFetching] = useState(true)
  const [newSection, setNewSection] = useState({ heading: "", description: "" })

  useEffect(() => {
    fetchPrivacyPolicy()
  }, [])

  const fetchPrivacyPolicy = async () => {
    try {
      setIsFetching(true)
      const response = await fetch("/api/admin/privacy-policy")
      const data = await response.json()

      if (data.success && data.privacyPolicy) {
        setFormData({
          _id: data.privacyPolicy._id,
          title: data.privacyPolicy.title || "Privacy Policy",
          content: data.privacyPolicy.content || "",
          sections: data.privacyPolicy.sections || [],
        })
      }
    } catch (error) {
      console.error("Error fetching privacy policy:", error)
      toast.error("Failed to load privacy policy")
    } finally {
      setIsFetching(false)
    }
  }

  const handleTitleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, title: e.target.value })
  }

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setFormData({ ...formData, content: e.target.value })
  }

  const handleSectionHeadingChange = (index: number, value: string) => {
    const updatedSections = [...formData.sections]
    updatedSections[index].heading = value
    setFormData({ ...formData, sections: updatedSections })
  }

  const handleSectionDescriptionChange = (index: number, value: string) => {
    const updatedSections = [...formData.sections]
    updatedSections[index].description = value
    setFormData({ ...formData, sections: updatedSections })
  }

  const handleAddSection = () => {
    if (newSection.heading.trim() && newSection.description.trim()) {
      setFormData({
        ...formData,
        sections: [...formData.sections, { ...newSection }],
      })
      setNewSection({ heading: "", description: "" })
      toast.success("Section added")
    } else {
      toast.error("Please fill in both heading and description")
    }
  }

  const handleRemoveSection = (index: number) => {
    const updatedSections = formData.sections.filter((_, i) => i !== index)
    setFormData({ ...formData, sections: updatedSections })
    toast.success("Section removed")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formData.title.trim() || !formData.content.trim()) {
      toast.error("Title and content are required")
      return
    }

    try {
      setIsLoading(true)
      const response = await fetch("/api/admin/privacy-policy", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          title: formData.title,
          content: formData.content,
          sections: formData.sections,
        }),
      })

      const data = await response.json()

      if (data.success) {
        toast.success("Privacy policy updated successfully!")
      } else {
        toast.error(data.message || "Failed to update privacy policy")
      }
    } catch (error) {
      console.error("Error updating privacy policy:", error)
      toast.error("Failed to update privacy policy")
    } finally {
      setIsLoading(false)
    }
  }

  if (isFetching) {
    return (
      <div className="flex items-center justify-center py-12">
        <Spinner />
      </div>
    )
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-8">
      {/* Title Field */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-[#6D4530]">Policy Title</label>
        <Input
          type="text"
          value={formData.title}
          onChange={handleTitleChange}
          placeholder="Enter policy title"
          className="border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396]"
        />
      </div>

      {/* Main Content Field */}
      <div className="space-y-2">
        <label className="block text-sm font-medium text-[#6D4530]">Main Content</label>
        <Textarea
          value={formData.content}
          onChange={handleContentChange}
          placeholder="Enter the main privacy policy content"
          className="min-h-32 border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396]"
        />
        <p className="text-xs text-[#8B5A3C]/60">This is the main introduction/summary of your privacy policy</p>
      </div>

      {/* Sections */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-[#6D4530]">Policy Sections</h3>

        {/* Existing Sections */}
        {formData.sections.length > 0 && (
          <div className="space-y-3">
            {formData.sections.map((section, index) => (
              <div key={index} className="p-4 bg-[#F9F7F5] rounded-lg border border-[#E5D5C5] space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <Input
                    type="text"
                    value={section.heading}
                    onChange={(e) => handleSectionHeadingChange(index, e.target.value)}
                    placeholder="Section heading"
                    className="border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396] font-medium"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => handleRemoveSection(index)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
                <Textarea
                  value={section.description}
                  onChange={(e) => handleSectionDescriptionChange(index, e.target.value)}
                  placeholder="Section description"
                  className="min-h-24 border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396]"
                />
              </div>
            ))}
          </div>
        )}

        {/* Add New Section */}
        <div className="p-4 bg-[#F5F1ED] rounded-lg border border-[#D9CFC7] space-y-3">
          <h4 className="font-medium text-[#6D4530]">Add New Section</h4>
          <Input
            type="text"
            value={newSection.heading}
            onChange={(e) => setNewSection({ ...newSection, heading: e.target.value })}
            placeholder="Section heading (e.g., Information We Collect)"
            className="border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396]"
          />
          <Textarea
            value={newSection.description}
            onChange={(e) => setNewSection({ ...newSection, description: e.target.value })}
            placeholder="Section description (e.g., We collect personal information...)"
            className="min-h-24 border-[#D9CFC7] text-[#6D4530] placeholder:text-[#B8A396]"
          />
          <Button
            type="button"
            onClick={handleAddSection}
            variant="outline"
            className="w-full border-[#8B5A3C] text-[#8B5A3C] hover:bg-[#8B5A3C] hover:text-white"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add Section
          </Button>
        </div>
      </div>

      {/* Submit Button */}
      <div className="flex gap-2 pt-4">
        <Button
          type="submit"
          disabled={isLoading}
          className="flex-1 bg-[#8B5A3C] hover:bg-[#6D4530] text-white"
        >
          {isLoading ? (
            <>
              <Spinner className="mr-2 h-4 w-4" />
              Updating...
            </>
          ) : (
            "Update Privacy Policy"
          )}
        </Button>
      </div>

      {/* Last Updated Info */}
      {formData.lastUpdated && (
        <p className="text-xs text-[#8B5A3C]/60 text-center pt-2">
          Last updated: {new Date(formData.lastUpdated).toLocaleDateString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </p>
      )}
    </form>
  )
}
