import mongoose, { type Document, type Model, Schema } from "mongoose"

export interface IPrivacyPolicy extends Document {
  title: string
  content: string
  sections: Array<{
    heading: string
    description: string
  }>
  lastUpdated: Date
  createdAt: Date
  updatedAt: Date
}

const PrivacyPolicySchema = new Schema<IPrivacyPolicy>(
  {
    title: {
      type: String,
      required: [true, "Title is required"],
      trim: true,
      default: "Privacy Policy",
    },
    content: {
      type: String,
      required: [true, "Content is required"],
    },
    sections: [
      {
        heading: {
          type: String,
          required: true,
        },
        description: {
          type: String,
          required: true,
        },
      },
    ],
    lastUpdated: {
      type: Date,
      default: Date.now,
    },
  },
  {
    timestamps: true,
  },
)

const PrivacyPolicy: Model<IPrivacyPolicy> =
  mongoose.models.PrivacyPolicy || mongoose.model<IPrivacyPolicy>("PrivacyPolicy", PrivacyPolicySchema)

export default PrivacyPolicy
